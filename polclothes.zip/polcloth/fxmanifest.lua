fx_version 'cerulean'
games { 'gta5' }

author 'isukki_#0994'
description 'Suomalaiset poliisivaatteet'